<?php

class Controller
{
	function __construct()
	{
		//echo "<br>Main Controller<br>";

		$this->view = new View();
	}

}
